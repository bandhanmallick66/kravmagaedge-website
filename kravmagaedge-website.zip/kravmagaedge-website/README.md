# Krav Maga Edge website

The website for Krav Maga Edge, a self-defense academy in Hyderabad.

## How to edit

- **Words, numbers and links:** open `index.html`, click the pencil icon, use your browser's find (Ctrl+F) to search for the text you see on the site, change it, then click **Commit changes**.
- **Testimonials:** in `index.html`, search for `testimonials-data`. Each testimonial is one `{ ... }` entry with a name, role and quote.
- **Photos:** upload new images into the `img` folder with **Add file → Upload files**. To replace a photo, upload one with exactly the same file name.
- **Logo animation:** `hero-logo.mp4` and `hero-logo.webm`.

Changes go live on the website within a couple of minutes. Every past version is kept under **History**, so any change can be undone.
